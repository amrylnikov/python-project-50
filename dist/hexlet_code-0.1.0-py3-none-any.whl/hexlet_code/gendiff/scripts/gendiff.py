def main():
    """Run an example code."""
    print('hi there')  # noqa:WPS432


if __name__ == '__main__':
    main()